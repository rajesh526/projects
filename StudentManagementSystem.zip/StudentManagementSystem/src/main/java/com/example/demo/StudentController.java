package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
@Controller
public class StudentController {
	@Autowired 
	JdbcTemplate jdbctemplate;
	@Autowired
	StudentService service;
	
	@RequestMapping("/")
	public String Index() {
		return "Index";
		
	}
	@RequestMapping("/AddStudent")
	public String StudentForm() {
		return "Student";
		
	}
	
	@RequestMapping(value="/SaveStudent", method=RequestMethod.POST)
	public String AddStudent(Student s,Model model) {
		String s1="select count(*) id from Student where id=?";
		int count=jdbctemplate.queryForObject(s1,new Object[]{s.getId()},Integer.class);
		if(count ==0) {
			 String sql="insert into Student (id,firstname,lastname,gender,dob,mail) values('"+s.getId()+"','"+s.getFirstname()+"','"+s.getLastname()+"','"+s.getGender()+"','"+s.getDob()+"','"+s.getGmail()+"')";
			 jdbctemplate.update(sql);
			return "Index";
		}
		else {
			model.addAttribute("Student", "Student");
			return "Student";
		}
		
		
	}
	@RequestMapping(value="/ViewStudent" ,method=RequestMethod.GET)
	public String getStudentDetails(Model model) {
		model.addAttribute("results", service.getAll());
		return "View";
		
	}
	
	
	@RequestMapping(value= "/edit/{id}")
	public String editStudent(@PathVariable int id,Model model) {
		 
		model.addAttribute("students",  service.getStudentById(id));
	
		return "EditStudent";
		
	}
	 @RequestMapping(value="/editsave",method = RequestMethod.POST)    
	    public String editsave(@ModelAttribute("student") Student student,Model model){    
	       service.update(student);    
	       model.addAttribute("results", service.getAll());
	        return "View";    
	    } 
	@RequestMapping(value="/delete/{id}",method = RequestMethod.GET)
	public String deleteStudent(@PathVariable int id,Model model) {
		service.delete(id);
		  model.addAttribute("results", service.getAll());
		return "View";
		
	}
	
	
	
	public ViewResolver getView() {
		InternalResourceViewResolver resolver=new InternalResourceViewResolver();
		resolver.setPrefix("/templates");
		resolver.setSuffix(".html");
		return resolver;
		
	}

}
