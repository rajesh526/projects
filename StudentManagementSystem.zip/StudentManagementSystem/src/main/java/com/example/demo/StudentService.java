package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

@Service
public class StudentService {
	@Autowired
	JdbcTemplate jdbctemplate;
	
	public List<Student> getAll(){
		String sql1="select *from student";
		RowMapper<Student> rm= new RowMapper<Student>() {

			@Override
			public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				Student s= new Student();
				s.setId(rs.getInt(1));
				s.setFirstname(rs.getString(2));
				s.setLastname(rs.getString(3));
				s.setGender(rs.getString(4));
				s.setDob(rs.getString(5));
				s.setGmail(rs.getString(6));
				return s;
			}
			
		};
		
		return jdbctemplate.query(sql1, rm);
		
	}
	public Student getStudentById(int id){    
	    String sql="select * from student where id=?";    
	    return jdbctemplate.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<Student>(Student.class));    
	} 
	public int update( Student s){    
		//Student s= new Student();
		System.out.println(s.getGmail());
		String sql="update student set id='"+s.getId()+"', firstname='"+s.getFirstname()+"', lastname='"+s.getLastname()+"',gender='"+s.getGender()+"',dob='"+s.getDob()+"',mail='"+s.getGmail()+"' where id='"+s.getId()+"'";    
	    //return jdbctemplate.update(sql);    
		//return jdbctemplate.queryForObject(sql, String.class);
	    return jdbctemplate.update(sql);
	}  
	
	public int delete(int id){    
	    String sql="delete from student where id="+id+"";
		return jdbctemplate.update(sql);    
	      
		
	}
	  

}
