package com.example.demo;

public class Student {
	public int id;
 public String firstname;
 public String lastname;
 public String gender;
 public String dob;
 public String gmail;
 public  Student() {
	 
 }
   public Student(int id,String firstname,String lastname,String gender,String dob,String gmail) {
	   this.id=id;
	   this.firstname=firstname;
	   this.lastname=lastname;
	   this.gender=gender;
	   this.dob=dob;
	   this.gmail=gmail;
   }
   public int getId() {
	   return id;
   }
   public void setId(int id) {
	   this.id=id;
   }
   public String getFirstname() {
	return firstname;
	   
   }
   public void setFirstname(String firstname) {
	   this.firstname=firstname;
   }
   
   public String getLastname() {
		return lastname;
		   
	   }
	   public void setLastname(String lastname) {
		   this.lastname=lastname;
	   }
   public String getGender() {
	   return gender;
   }
   public void setGender(String gender) {
	   this.gender=gender;
   }
   public String getDob() {
	   return dob;
   }
   public void setDob(String dob) {
	   this.dob=dob;
   }
   public String getGmail() {
	return gmail;
	   
   }
   public void setGmail(String mail) {
	   this.gmail=mail;
   }
   
 
	

}
