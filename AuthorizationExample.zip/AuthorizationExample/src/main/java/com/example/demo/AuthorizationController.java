package com.example.demo;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;




public class AuthorizationController {
	
	@Autowired
	AuthorizationRepository repository;
	
	 
	@RequestMapping("/openminds")
	public String index() {
		return "index";
	}
	@RequestMapping("/index")
	public String Home() {
		return "index";
	}
	@RequestMapping("/About")
	public String About() {
		return "About";
	}
	@RequestMapping("/Academic")
	public String Academic() {
		return "Academic";
	}
	@RequestMapping("/Academics")
	public String Academics() {
		return "Academics";
	}
	@RequestMapping("/Admission")
	public String Admission() {
		return "Admission";
	}
	@RequestMapping("/Campus")
	public String Campus() {
		return "Campus";
	}
	@RequestMapping("/Contact")
	public String Contact() {
		return "Contact";
	}
	@RequestMapping("/directormsg")
	public String director() {
		return "directormsg";
	}
	@RequestMapping("/Gallery")
	public String Gallery() {
		return "Gallery";
	}
	@RequestMapping("/Info")
	public String Info() {
		return "Info";
	}
	@RequestMapping("/Infrastructure")
	public String Infrastructure () {
		return "Infrastructure";
	}
	@RequestMapping("/Medical")
	public String Medical() {
		return "Medical";
	}
	@RequestMapping("/MiddlePrimary")
	public String MPrimary() {
		return "MiddlePrimary";
	}
	@RequestMapping("/mission")
	public String Mission() {
		return "mission";
	}
	@RequestMapping("/primary")
	public String primary() {
		return "primary";
	}
	
	@RequestMapping("/prinicipalmsg")
	public String PrinicipalMsg() {
		return "prinicipalmsg";
	}
	
	@RequestMapping("/Secondary")
	public String Secondary() {
		return "Secondary";
	}
	@RequestMapping("/Sports")
	public String Sports() {
		return "Sports";
	}
	@RequestMapping("/Transport")
	public String Transport() {
		return "Transport";
	}

	@RequestMapping("/Admissiondetails")
	public String AdmissionDetails() {
		return "AdmissionDetails";
	}
	
	@RequestMapping("/facebook")
	public String Facebook() {
		return "facebook";
		
	}
	
	
	
	
	

	@RequestMapping("/Register")
	public String redirect() {
		return "Register";
		
	}
	@RequestMapping("/Forgot")
	public String Fogot() {
		return "Forgot";
		
	}
	
	
	//register 
	@Valid
	@RequestMapping(value="/save",method = RequestMethod.POST ,consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public @ResponseBody  String saveform( @Valid Register t ,Model model,BindingResult result){
		repository.save(t);
		//System.out.println("Successfully registered");
		return "Index";
	
	
		/*String s="select count(*) username from register1 where username=?";
		int count=jdbctemplate.queryForObject(s,new Object[] {t.getUsername()},Integer.class);
		if( count == 0) {
		
		String query="insert into register1(firstname,lastname,email,username,password,confirmpassword) values('"+t.getFirstname()+"','"+t.getLastname()+"','"+t.getEmail()+"','"+t.getUsername()+"','"+t.getPassword()+"','"+t.getConfirmpassword()+"')";
		jdbctemplate.update(query);
	
		return "Sign"; 
		}
		else {
			model.addAttribute("UserExists", "UserExists");
			return "Register"; 
		}
		*/
		
	}
	
	//view Registered Details
	@RequestMapping(value = "/RegisterDetails", method = RequestMethod.GET)
    public String viewDetails(Model md){
		return "Sign";
		
		  /* md.addAttribute("results", service.getAll());
		   Gson gson =new Gson();
		   String json =gson.toJson(md);
	       //System.out.println(json);
	       //System.out.println(res.length());
	       JSONObject resultObject = new JSONObject(json);
           JSONArray JArray = resultObject.getJSONArray("results");
		

			                  for (int i=0; i<JArray.length(); i++) {

			                      JSONObject JObject =JArray.getJSONObject(i);
			                   System.out.println(JObject);
			                   
			                  }
			                  
	       
	       return "RegisterDetails";
    }
	
	//login
	@RequestMapping(value="/Sign")
	public String login() {
		return "Sign";
		*/
	}
	
	//Login validation
	@RequestMapping(value = "/valid", method=RequestMethod.POST)
    public String username(Model md2,Register t,BindingResult result){
		return "Sign";
   
/*
		   md2.addAttribute("results2", service.usernameandpassword());
		   
		   Gson gson2 =new Gson();
		   String res2=gson2.toJson(md2);
		   
		      JSONObject resultObject = new JSONObject(res2);
           JSONArray JArray = resultObject.getJSONArray("results2");
			

			            for (int i=0; i<JArray.length(); i++) {

			                      JSONObject JObject =JArray.getJSONObject(i);
			                  
			                       
			                    if((JObject.get("username").equals(t.getUsername())) & (JObject.get("password").equals(t.getPassword()))) {
			                	
			                      return "view";
			                	    
			                       }
			                     else if((JObject.get("username")!=(t.getUsername())) & (JObject.get("password")!=(t.getPassword()))) {
			                	 
			                    	 md2.addAttribute("logError","logError");
			                         
			                	  
			                  }
			          }
			            return "Sign";
			*/
	}
	
	//Enquiry
	@RequestMapping("/enquiry")
	public String redirect2(Model model) {
		
		return "enquiry";
		
	}
	//Submit Enquiry form
	@RequestMapping(value="/onlineenquiry",method=RequestMethod.POST)
	public String Enquiryform( Enquiry e, Model model) {
		/*Date date=new Date(e.getDob());
		

		String sql2="insert into  enquiry1 (firstname,middlename,lastname, dob, nationality,gender,selectclass,reference,fathername,fatherqualification,fatheroccupation,mothername,motherqualification,motheroccupation,mobile,email)values('"+e.getFirstname()+"','"+e.getMiddlename()+"','"+e.getLastname()+"', '"+date+"','"+e.getNationality()+"','"+e.getGender()+"','"+e.getSelectclass()+"','"+e.getReference()+"','"+e.getFathername()+"','"+e.getFatherqualification()+"','"+e.getFatheroccupation()+"','"+e.getMothername()+"','"+e.getMotherqualification()+"','"+e.getMotheroccupation()+"','"+e.getMobile()+"','"+e.getEmail()+"')";
		System.out.println(jdbctemplate.update(sql2));
		model.addAttribute("enquiry","enquiry");
		
	
	return "enquiry";
		
	}
	@RequestMapping(value = "/AdmissionDetails", method = RequestMethod.GET)
    public String Admissiondetails(Model md){
		
		   md.addAttribute("results1", service.Admissiondetails());
		   Gson gson =new Gson();
		   String json =gson.toJson(md);
	       //System.out.println(json);
	       //System.out.println(res.length());
	       JSONObject resultObject = new JSONObject(json);
           JSONArray JArray = resultObject.getJSONArray("results1");
		

			                  for (int i=0; i<JArray.length(); i++) {

			                      //JSONObject JObject =JArray.getJSONObject(i);
			                   //System.out.println(JObject);
			                   
			                  }
			                  */
	       
	       return "AdmissionDetails";
    }
	

}
