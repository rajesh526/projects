package com.tony;

import org.springframework.format.annotation.DateTimeFormat;

public class Enquiry {
	private String firstname;
	private String middlename;
	private String lastname;
	@DateTimeFormat(pattern="yyyy-mm-dd")
	private long dob;
	private String nationality;
	private String gender;
	private String selectclass;
	private String refernece;
	private String fathername;
	private String fatherqualification;
	private String fatheroccupation;
	private String mothername;
	private String motherqualification;
	private String motheroccupation;
	private String mobile;
	private String email;
	
	Enquiry(){
		
	}
	Enquiry(String firstname,String middlename,String lastname, long dob,String nationality,String gender, String selectclass,String reference, String fathername,String fatherqualification,String fatheroccupation,String mothername,String motherqualification, String motheroccupation, String mobile ,String email){
		super();
		this.firstname=firstname;
		this.middlename=middlename;
		this.lastname=lastname;
		this.dob=dob;
		this.nationality=nationality;
		this.gender=gender;
		this.selectclass=selectclass;
		this.refernece=reference;
		this.fathername =fathername;
		this.fatherqualification=fatherqualification;
		this.fatheroccupation=fatheroccupation;
		this.mothername=mothername;
		this.motherqualification=motherqualification;
		this. motheroccupation= motheroccupation;
		this.mobile= mobile;
		this. email=email;
		
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname=firstname;
	}
	public String getMiddlename() {
		return middlename;
	}
	public void setMiddlename(String middlename) {
		this.middlename=middlename;
		}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String Lastname) {
		
	}
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality=nationality;
		}
	public long getDob() {
		return dob;
	}
	public void setDob(long dob) {
		this.dob=dob;		
		}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender=gender;
	}
	public String getSelectclass() {
		return selectclass;
	}
	public void setSelectclass(String selectclass) {
		this.selectclass=selectclass;
		}
	public String getReference() {
		return refernece;
	}
	public void setReference(String reference) {
		this.refernece=reference;	
	}
	public String getFathername() {
		return fathername;
	}
	public void setFathername(String fathername) {
		this.fathername=fathername;
		}
	public String getFatherqualification() {
		return fatherqualification;
	}
	public void setFatherqualification(String fatherqualification) {
		this.fatherqualification=fatherqualification;	
	}
	public String getFatheroccupation() {
		return fatheroccupation;
	}
	public void setFatheroccupation(String fatheroccupation) {
		this.fatheroccupation=fatheroccupation;	
	}
	public String getMothername() {
		return mothername;
	}
	public void setMothername(String mothername) {
		this.mothername=mothername;
		}
	public String getMotherqualification() {
		return motherqualification;
	}
	public void setMotherqualification(String motherqualification) {
		this.motherqualification=motherqualification;
		}
	public String getMotheroccupation() {
		return motheroccupation;
	}
	public void setMotheroccupation(String motheroccupation) {
		this.motheroccupation=motheroccupation;
		}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile=mobile;
		}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email=email;
		}
	

}
