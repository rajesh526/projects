package com.tony;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;

@SpringBootApplication(exclude = {SecurityAutoConfiguration.class })
public class Rajesh1Application {
@Autowired
RegisterService1 service;
	public static void main(String[] args) {
		SpringApplication.run(Rajesh1Application.class, args);
	}

}
