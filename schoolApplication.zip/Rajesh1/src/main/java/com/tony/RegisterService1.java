package com.tony;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
@Service
public class RegisterService1 {
	@Autowired
	JdbcTemplate jdbcTemplate;
	public List<Register> getAll(){
		String sql="select*from register1";
		RowMapper<Register> rm = new RowMapper<Register>() {
            @Override
            public Register mapRow(ResultSet rs, int i) throws SQLException {
            Register result = new Register();
            result.setFirstname(rs.getString(1));
            result.setLastname(rs.getString(2));
            result.setEmail(rs.getString(3));
            result.setUsername(rs.getString(4));
            result.setPassword(rs.getString(5));
            result.setConfirmpassword(rs.getString(6));
           
               
          
                return result;
                
            }
        };
      
	return jdbcTemplate.query(sql, rm);
		
		
	}
	public List<Register> usernameandpassword(){
		String sql2="select username,password from register1";
		RowMapper<Register> rm = new RowMapper<Register>() {
            @Override
            public Register mapRow(ResultSet rs, int i) throws SQLException {
            Register res1 = new Register();
        
          
            res1.setUsername(rs.getString(1));
            res1.setPassword(rs.getString(2));
           
           
               
          
                return res1;
                
            }
        };
      return  jdbcTemplate.query(sql2, rm);
		
	}
	public List<Enquiry> Admissiondetails(){
		String sql="select*from enquiry1 ";
		RowMapper<Enquiry> rm = new RowMapper<Enquiry>() {
            @Override
            public Enquiry mapRow(ResultSet rs, int i) throws SQLException {
            Enquiry result1 = new Enquiry();
            result1.setFirstname(rs.getString(1));
            result1.setMiddlename(rs.getString(2));
            result1.setLastname(rs.getString(3));
            result1.setDob(rs.getLong(4));
            result1.setNationality(rs.getString(5));
            result1.setGender(rs.getString(6));
            result1.setSelectclass(rs.getString(7));
            result1.setReference(rs.getString(8));
            result1.setFathername(rs.getString(9));
            result1.setFatherqualification(rs.getString(10));
            result1.setFatheroccupation(rs.getString(11));
            result1.setMothername(rs.getString(12));
            result1.setMotherqualification(rs.getString(13));
            result1.setMotheroccupation(rs.getString(14));
            result1.setMobile(rs.getString(15));
            result1.setEmail(rs.getString(16));
           
           
               
          
                return result1;
                
            }
        };
      
	return jdbcTemplate.query(sql, rm);
		
		
	}
	
}
