package com.example.demo;

import java.sql.Blob;

import org.springframework.web.multipart.MultipartFile;

public class ImageValidation {
	public String  name;
	public Blob image;
	
	ImageValidation(){
		
	}
	ImageValidation(String name,Blob image){
		this.name=name;
		this.image=image;
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name=name;
	}
	public Blob getImage(){
		return image;
		
	}
	public void setImage(Blob image) {
		this.image=image;
	}
	
}
