 package com.example.demo;

import java.io.IOException;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
@Service
public class ImageValidationService {
	@Autowired
	JdbcTemplate jdbctemplate;
	
	

	public List<ImageValidation> getAll(){
		String sql2="select*from upload";
		RowMapper<ImageValidation> rm = new RowMapper<ImageValidation>() {
            @Override
			public ImageValidation mapRow(ResultSet rs, int rowNum) throws SQLException {
            	ImageValidation res1 = new ImageValidation();
                res1.setName(rs.getString(1));
               
                res1.setImage(rs.getBlob(2));
                return res1;
            
			}   
        };
      
		return  jdbctemplate.query(sql2, rm);
		}
	
	public Blob getPhotoByName(String name) throws SQLException, IOException, JSONException {
	
		String query = "select image from upload where name= ?";
		Blob photo = jdbctemplate.queryForObject(query,new Object[] {name},  Blob.class);
		return photo;
	}





	
	
}
