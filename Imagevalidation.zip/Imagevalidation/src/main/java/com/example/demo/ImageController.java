package com.example.demo;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Blob;
import java.sql.SQLException;
import java.sql.Types;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.rowset.serial.SerialBlob;
import javax.sql.rowset.serial.SerialException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.SqlLobValue;
import org.springframework.jdbc.support.lob.DefaultLobHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.google.gson.Gson;

@Controller

public class ImageController {
	@Autowired
	JdbcTemplate jdbctemplate;
	@Autowired
	ImageValidationService service;
	
	
	
	
	@RequestMapping("/")
	public String Home() {
		return "Image";
		
	}
	
	@RequestMapping(value="/upload" ,method=RequestMethod.POST)
	public String Upload(@RequestParam MultipartFile image, @RequestParam String name) throws IOException {
		System.out.println(" nmae s  :: "+name);
		FileInputStream fileInputStream;
		if(image!=null) {
			 try {
				fileInputStream=(FileInputStream) image.getInputStream();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else {
			System.out.println("image is null please check");
		}
		String s= "select count(*) name from upload where name=?";
		int count =jdbctemplate.queryForObject(s,new  Object[] {name},Integer.class);
		 String s1 ="insert into upload (name,image) values (?,?)";
		 byte[] data=image.getBytes();
			
			
		if (count ==0) {
			String sql=null;
			sql = "insert into upload (name,image) values ('"+name+"','"+ new SqlLobValue(new ByteArrayInputStream(data), data.length, new DefaultLobHandler())+"')";
			 //String s1 ="insert into upload (name,image) values (?,?)";
			jdbctemplate.update(s1,new Object[] {name, new SqlLobValue(new ByteArrayInputStream(data), data.length, new DefaultLobHandler())},new int[] {Types.VARCHAR,Types.BLOB});
			return "View";
			
		}
		else {
			//model.addAttribute("FileName", "FileName");
			return "Image";
			
		}	
	}
	
	
	@RequestMapping(value="/get",method=RequestMethod.GET)
	public String ImageResults(Model model,HttpServletResponse response) throws JSONException, SQLException, IOException {
		
		model.addAttribute("results", service.getAll());
		
		Gson gson =new Gson();
		   String json =gson.toJson(model);
		   JSONObject resultObject = new JSONObject(json);
           JSONArray JArray = resultObject.getJSONArray("results");
  
                for (int i=0; i<JArray.length(); i++) {
			         //JSONObject JObject =JArray.getJSONObject(i);
			        
			        
			    }
               
		return "Result";
		
	}
	
	
	@RequestMapping(value="/PhotoName/name/" )
	
	public void Result(HttpServletResponse response,HttpServletRequest request ,Model model,@PathVariable("name") String name)  throws IOException, SQLException, JSONException {
		response.setContentType("image/jpeg,image/jpg,image/png,image/gif,image/jfif");
		
	
              Blob blob=service.getPhotoByName( name) ;
              
              byte [] bytes = blob.getBytes(1l, (int)blob.length());
              //BufferedImage img = ImageIO.read(new ByteArrayInputStream(bytes));
              ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
              BufferedImage bImage2 = ImageIO.read(bis);
              ImageIO.getImageReaders(bImage2);
              System.out.println("image created");
              
              }
	
	
	@Bean
	public ViewResolver getView() {
		InternalResourceViewResolver resolver= new InternalResourceViewResolver ();
		resolver.setPrefix("templates/");
		resolver.setSuffix(".html");
		return resolver;
		
	}

}
