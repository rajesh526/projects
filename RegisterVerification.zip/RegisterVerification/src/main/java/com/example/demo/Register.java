package com.example.demo;

public class Register {
	
	public String username;
	public String mail;
	public String password;
	public Boolean isenabled;
	
	public Register() {
		
	}
	public Register(String username,String mail,String password) {
		this.username=username;
		this.mail=mail;
		this.password=password;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username=username;
	}
	
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail=mail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password=password;
	}
	public Boolean getIsenabled() {
		return isenabled;
	}
	public void setIsenabled(Boolean isenabled) {
		this.isenabled=isenabled;
	}



}
