package com.example.demo;

import java.util.Properties;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Controller
public class RegisterVerficationController {
	@Autowired
	JdbcTemplate template;
	 @Autowired
	   private EmailService emailService;
	 
	
	@RequestMapping("/")
	public String index() {
		return "Register"; 
		
	}
	@RequestMapping(value="/register",method=RequestMethod.POST)
	public String RegisterUser( Register register,Model  model,User user) {
		//System.out.println(register.getMail());
		String sql="insert into registerverification (username,mail,password) values('"+register.getUsername()+"','"+register.getMail()+"','"+register.getPassword()+"')";
		 template.update(sql);
		 ConfirmationToken confirmationToken = new ConfirmationToken(user);

         //emailService.save(confirmationToken);
		  SimpleMailMessage mailMessage = new SimpleMailMessage();
		  Properties properties= new Properties();
		  properties.put("mail.smtp.starttls.enable", "true");
          mailMessage.setTo(register.getMail());
          mailMessage.setSubject("Complete Registration!");
          mailMessage.setFrom("jagarlamudi435@gmail.com");
          mailMessage.setText("To confirm your account, please click here : "
          +"http://localhost:8080/confirm-account?token="+confirmationToken.getConfirmationToken());
          emailService.sendEmail(mailMessage);

          model.addAttribute("emailId", register.getMail());
		return "RegisterSuccess";
		
	}
	 @Bean
		public ViewResolver getView() {
			InternalResourceViewResolver resolver= new InternalResourceViewResolver ();
			resolver.setPrefix("templates/");
			resolver.setSuffix(".html");
			return resolver;
			
		}

}
