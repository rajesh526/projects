package com.example.demo;



import java.sql.Date;
import java.util.UUID;

import org.apache.catalina.User;

public class ConfirmationToken {
	
	    private long tokenid;
	    private String confirmationToken;
	    private Date createdDate;
	    private User user;

	    public ConfirmationToken(User user) {
	        this.setUser(user);
	        setCreatedDate(new Date(tokenid));
	        setConfirmationToken(UUID.randomUUID().toString());
	    }

	    public long getTokenid() {
			return tokenid;
		}

		public void setTokenid(long tokenid) {
			this.tokenid = tokenid;
		}
		public String getConfirmationToken() {
			return confirmationToken;
		}

		public void setConfirmationToken(String confirmationToken) {
			this.confirmationToken = confirmationToken;
		}

		public Date getCreatedDate() {
			return createdDate;
		}

		public void setCreatedDate(Date createdDate) {
			this.createdDate = createdDate;
		}

		public User getUser() {
			return user;
		}

		public void setUser(User user) {
			this.user = user;
		}

	   
	}


