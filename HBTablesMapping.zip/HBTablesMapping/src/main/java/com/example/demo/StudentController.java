package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class StudentController {
	
	 @Autowired
	   StudentService service;
	

	@RequestMapping("/")
	public String index() {
		return "index";
		
	}
	@RequestMapping("/Register")
	public String RegisterPage() {
		return "Register";
		
	}
	
	
     @RequestMapping(value="/AddUser",method=RequestMethod.POST, consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public String AddUser(Student student) throws Exception{
    service.createOrUpdateStudnet(student);
    	 
		return "index";
		
	}
     @RequestMapping(value="/get", method=RequestMethod.GET)
     public String getAll(Student e,Model model) {
    	 model.addAttribute("results",service.getAllStudents());
    	
		 return "view";
    	 
     }
     @RequestMapping(value= "/edit/{id}")
  	public String editStudent(@PathVariable   int id ,Model model) throws Exception {
  		 
  		model.addAttribute("employees",  service.getStudentsId(id));
  	
  		return "EditEmployee";
  		
  	}
     @RequestMapping(value="/editsave",method = RequestMethod.POST)    
	    public String editsave(@ModelAttribute("employee") Student  student,Model model) throws Exception{    
    	 service.createOrUpdateStudnet(student);
	       model.addAttribute("results", service.getAllStudents());
	        return "view";    
	    }
     /*
     @RequestMapping(value= "/edit/{email}")
 	public String editStudent(@PathVariable String email,Model model) {
 		 
 		model.addAttribute("employees",  repository.findByEmail(email));
 	
 		return "EditEmployee";
 		
 	}
     @RequestMapping(value="/editsave",method = RequestMethod.POST)    
	    public String editsave(@ModelAttribute("student") Employee employee,Model model){    
	       repository.update(employee);    
	       model.addAttribute("results", repository.findAll());
	        return "view";    
	    } */
 	@RequestMapping(value="/delete/{id}",method = RequestMethod.GET)
 	public String deleteStudent(@PathVariable int id ,Model model) throws Exception {
 		service.deleteStudentById(id);
 		  model.addAttribute("results", service.getAllStudents());
 		return "view";
 		
 	}
 	
	

}
