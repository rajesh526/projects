package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

@Service
public class EmployeeService {
	@Autowired
	EmployeeRepository repository;

	//Update 
	public Employee Update(String firstname,String lastname,String email,String username,String password,String confirmpassword) {
		Employee e=repository.findByEmail(email);
	e.setFirstname(firstname);
	e.setLastname(lastname);
	e.setEmail(email);
	e.setUsername(username);
	e.setPassword(confirmpassword);
	e.setConfirmpassword(confirmpassword);
	return repository.save(e);
	}
	
	//Delete
	public void deletebymail(@PathVariable String email) {
		Employee e=repository.findByEmail(email); 
		repository.delete(e);
	}
	
}
