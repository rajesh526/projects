package com.example.demo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MvcConfig  implements WebMvcConfigurer{
	@Bean
	public BCryptPasswordEncoder passwordEncoder() {
	    BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
	    return bCryptPasswordEncoder;
	}
	
	public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/").setViewName("home");
        registry.addViewController("/index").setViewName("index");
        registry.addViewController("/About").setViewName("About");
        registry.addViewController("/Academic").setViewName("Academic");
        registry.addViewController("/Academics").setViewName("Academics");
        registry.addViewController("/Admission").setViewName("Admission");
        registry.addViewController("/Admissiondetails").setViewName("Admissiondetails");
        registry.addViewController("/Campus").setViewName("Campus");
        registry.addViewController("/Contact").setViewName("Contact");
        registry.addViewController("/directormsg").setViewName("directormsg");
        registry.addViewController("/enquiry").setViewName("enquiry");
        registry.addViewController("/Forgot").setViewName("Forgot");
        registry.addViewController("/Gallery").setViewName("Gallery");
        registry.addViewController("/Info").setViewName("Info");
        registry.addViewController("/Infrastructure").setViewName("Infrastructure");
        registry.addViewController("/Medical").setViewName("Medical");
        registry.addViewController("/MiddlePrimary").setViewName("MiddlePrimary");
        registry.addViewController("/mission").setViewName("mission");
        registry.addViewController("/primary").setViewName("primary");
        registry.addViewController("/prinicipalmsg").setViewName("prinicipalmsg");
        registry.addViewController("/Register").setViewName("Register");
        registry.addViewController("/RegisterDetails").setViewName("RegisterDetails");
        registry.addViewController("/Secondary").setViewName("Secondary");
        registry.addViewController("/Sign").setViewName("Sign");
        registry.addViewController("/signup").setViewName("signup");
        registry.addViewController("/Sports").setViewName("Sports");
        registry.addViewController("/Transport").setViewName("Transport");
        registry.addViewController("/view").setViewName("view");
        registry.addViewController("/Register").setViewName("Sign");
       

    }
	
	

}
