package com.example.demo;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;




@Controller
public class UserController {
	@Autowired
	private CustomUserDetailsService userService;
	
	@RequestMapping("/")
	public String inde() {
		return "home";
	}
	
	@RequestMapping("/index")
	public String Home() {
		return "index";
	}
	@RequestMapping("/About")
	public String About() {
		return "About";
	}
	@RequestMapping("/Academic")
	public String Academic() {
		return "Academic";
	}
	@RequestMapping("/Academics")
	public String Academics() {
		return "Academics";
	}
	@RequestMapping("/Admission")
	public String Admission() {
		return "Admission";
	}
	@RequestMapping("/Campus")
	public String Campus() {
		return "Campus";
	}
	@RequestMapping("/Contact")
	public String Contact() {
		return "Contact";
	}
	@RequestMapping("/directormsg")
	public String director() {
		return "directormsg";
	}
	@RequestMapping("/Gallery")
	public String Gallery() {
		return "Gallery";
	}
	@RequestMapping("/Info")
	public String Info() {
		return "Info";
	}
	@RequestMapping("/Infrastructure")
	public String Infrastructure () {
		return "Infrastructure";
	}
	@RequestMapping("/Medical")
	public String Medical() {
		return "Medical";
	}
	@RequestMapping("/MiddlePrimary")
	public String MPrimary() {
		return "MiddlePrimary";
	}
	@RequestMapping("/mission")
	public String Mission() {
		return "mission";
	}
	@RequestMapping("/primary")
	public String primary() {
		return "primary";
	}
	
	@RequestMapping("/prinicipalmsg")
	public String PrinicipalMsg() {
		return "prinicipalmsg";
	}
	
	@RequestMapping("/Secondary")
	public String Secondary() {
		return "Secondary";
	}
	@RequestMapping("/Sports")
	public String Sports() {
		return "Sports";
	}
	@RequestMapping("/Transport")
	public String Transport() {
		return "Transport";
	}

	@RequestMapping("/Admissiondetails")
	public String AdmissionDetails() {
		return "AdmissionDetails";
	}
	
	@RequestMapping("/facebook")
	public String Facebook() {
		return "facebook";
		
	}
	
	
	
	
	

	@RequestMapping("/Register")
	public String redirect() {
		return "Register";
		
	}
	@RequestMapping("/Forgot")
	public String Fogot() {
		return "Forgot";
		
	}
	
	/*
	//register 
	@Valid
	@RequestMapping(value="/save",method = RequestMethod.POST)
	public String saveform(@Valid Register user ,Model model,BindingResult result){
		Register userExists = userService.findUserByUsername(user.getEmail());
		 if (userExists != null) {
		        result
		                .rejectValue("username", "error.user",
		                        "There is already a user registered with the username provided");
		    }
		 if (result.hasErrors()) {
		       return "Register";
		    } else {
		        userService.saveUser(user);
		        //model.addObject("successMessage", "User has been registered successfully");
		        //modelAndView.addObject("user", new User());
		        //modelAndView.setViewName("login");

		    }
		return "Sign";
	
		
		
		
	
		}
		*/
		
	
	
	
	//login
	@RequestMapping(value = "/Sign", method = RequestMethod.GET)
	public ModelAndView login() {
	    ModelAndView modelAndView = new ModelAndView();
	    //modelAndView.setViewName("");
	    return modelAndView;
	}
	
	
	@RequestMapping(value = "/Register", method = RequestMethod.GET)
	public ModelAndView signup() {
	    ModelAndView modelAndView = new ModelAndView();
	    Register user = new Register();
	    modelAndView.addObject("user", user);
	    modelAndView.setViewName("Register");
	    return modelAndView;
	}
	
	@RequestMapping(value = "/Register", method = RequestMethod.POST)
	public ModelAndView createNewUser(@Valid Register user, BindingResult bindingResult) {
	    ModelAndView modelAndView = new ModelAndView();
	    Register userExists = userService.findUserByUsername(user.getUsername());
	    if (userExists != null) {
	        bindingResult
	                .rejectValue("username", "error.user",
	                        "There is already a user registered with the username provided");
	    }
	    if (bindingResult.hasErrors()) {
	        modelAndView.setViewName("Register");
	    } else {
	        userService.saveUser(user);
	        modelAndView.addObject("successMessage", "User has been registered successfully");
	        modelAndView.addObject("user", new Register());
	        modelAndView.setViewName("login");

	    }
	    return modelAndView;
	}


	
	
	
	/*
	@Bean
	   public ViewResolver getViewResolver() {
	       InternalResourceViewResolver resolver = new InternalResourceViewResolver();
	       resolver.setPrefix("templates/");
	       resolver.setSuffix(".html");
	       return resolver;
	   } 
	   
	   */

}
